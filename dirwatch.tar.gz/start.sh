#!/bin/bash
cd DirectoryWatch
./DirectoryWatch.elf

